# n8n workflows — CoAction CRM (NocoDB)

7 importowalnych workflowów zgodnych ze schematem `nocodb_crm_schema_v2.md`:

| Plik | Trigger | Co robi |
|---|---|---|
| `W1_recurring_tasks.json` | cron 06:00 | taski cykliczne z `task_templates` (RRULE: DAILY / WEEKLY;BYDAY / MONTHLY;BYMONTHDAY), z guardem idempotencji |
| `W2_stage_change.json` | webhook: leads update | kamienie milowe + `state`, task "uzupełnij powód utraty", mail do ownera |
| `W3_task_notifications.json` | webhook: tasks insert **i** update | mail do assignee przy nowym tasku / zmianie assignee |
| `W4_new_lead_intake.json` | webhook: Tally | lead + task "Schedule discovery call" dla Przemka |
| `W5_company_dedup.json` | webhook: leads insert | dopasowanie firmy po domenie, `pending_confirmation`, komentarz, mail |
| `W6a_meeting_ai_pipeline.json` | webhook: meetings update | transkrypcja → OpenRouter → `ai_analysis` → task weryfikacji; akceptacja → task "cele" (routing B2B→Dorota / B2C→Aleksandra); odrzucenie / brak transkrypcji → task naprawczy |
| `W6b_offer_pipeline.json` | webhook: leads update | `goals_provided` → task referencji; `testimonials_provided` → walidacja linków → task "złóż ofertę" + `draft_ready` |

Każdy workflow kończy się wpisem do `activities` (+ link do leada tam, gdzie lead jest znany).

## 1. Podmień placeholdery (PRZED importem)

```bash
cd n8n
sed -i \
 -e 's|__NOCODB_URL__|https://noco.twojadomena.pl|g' \
 -e 's|__TBL_LEADS__|m1a2b3...|g' \
 -e 's|__TBL_TASKS__|...|g' \
 -e 's|__TBL_TASK_TEMPLATES__|...|g' \
 -e 's|__TBL_ACTIVITIES__|...|g' \
 -e 's|__TBL_MEETINGS__|...|g' \
 -e 's|__TBL_COMPANIES__|...|g' \
 -e 's|__LNK_ACT_LEAD__|c_...|g' \
 -e 's|__LNK_LEAD_COMPANY__|c_...|g' \
 -e 's|__LNK_LEAD_TESTIMONIALS__|c_...|g' \
 -e 's|__LNK_MEETING_LEAD__|c_...|g' \
 -e 's|__EMAIL_PRZEMEK__|przemek@...|g' \
 -e 's|__EMAIL_DOROTA__|dorota@...|g' \
 -e 's|__EMAIL_ALEKSANDRA__|aleksandra@...|g' \
 -e 's|__EMAIL_ANALYST__|...@...|g' \
 -e 's|__MAIL_FROM__|crm@twojadomena.pl|g' \
 -e 's|__OPENROUTER_MODEL__|anthropic/claude-sonnet-4.5|g' \
 *.json
```

ID tabel (`m...`) i ID pól linkujących (`c...`): w NocoDB otwórz tabelę → menu → *API Snippet* / *Swagger*, albo `GET /api/v2/meta/bases/{baseId}/tables`. ID pola linku znajdziesz w `GET /api/v2/meta/tables/{tableId}/columns` (szukaj typu `Links`).

## 2. Credentials w n8n (3 sztuki)

1. **NocoDB Token** — typ *Header Auth*: name `xc-token`, value = token z NocoDB (Account → Tokens). Przypisz do wszystkich node'ów HTTP po imporcie (n8n podpowie po nazwie).
2. **OpenRouter** — typ *Header Auth*: name `Authorization`, value `Bearer sk-or-...` (tylko W6a).
3. **SMTP** — do node'ów Send Email (W2, W3, W5). Zamiana na Slack/Telegram = podmiana jednego node'a.

## 3. Webhooki w NocoDB

Dla każdego workflow z triggerem webhook: tabela → *Details* → *Webhooks* → *Create*:

| Workflow | Tabela | Event | URL n8n |
|---|---|---|---|
| W2 | leads | after **update** | `https://n8n.../webhook/w2-stage-change` |
| W3 | tasks | after **insert** ORAZ drugi after **update** | `.../webhook/w3-task-notify` (oba na ten sam URL) |
| W5 | leads | after **insert** | `.../webhook/w5-company-dedup` |
| W6a | meetings | after **update** | `.../webhook/w6a-meeting-ai` |
| W6b | leads | after **update** | `.../webhook/w6b-offer-pipeline` |

**KRYTYCZNE:** w każdym webhooku NocoDB zaznacz **"Include previous record"** (send me everything / previous state). Bez tego guardy `rows` vs `previous_rows` nie mają czego porównywać i workflowy odpalą się przy KAŻDEJ edycji rekordu — w W6a oznacza to płatne wywołanie LLM przy każdej poprawce literówki w notatce.

W4: URL `.../webhook/w4-tally-intake` wklej w Tally → Integrations → Webhooks.

## 4. Kolejność uruchamiania i test

Włączaj po jednym: **W3 → W2 → W1 → W4 → W5 → W6a → W6b** (powiadomienia najpierw). Po każdym: wykonaj akcję testową w NocoDB i sprawdź execution log w n8n + wpis w `activities`.

Smoke test W6 (scenariusz "Piotr"): utwórz testowy lead + spotkanie z linkiem do leada → wklej transkrypcję → `processing_status = analysis_pending` → sprawdź `ai_analysis`, task weryfikacji i activity → `ai_accepted` → sprawdź task celów u właściwej metodyczki → na leadzie `goals_provided` → task referencji → podlinkuj testimonial → `testimonials_provided` → task dla Przemka + `draft_ready`.

## 5. Znane uproszczenia (do świadomej akceptacji)

- **Kształt payloadu webhooków NocoDB różni się między wersjami** (pole User: obiekt vs tablica; linki: licznik vs obiekt). Guardy piszą defensywnie oba warianty, ale po pierwszym realnym wywołaniu obejrzyj payload w execution logu i w razie czego popraw ścieżki w Code node'ach. To najbardziej prawdopodobne miejsce jednorazowej korekty.
- **Wiązanie tasków z pipeline'em** działa przez marker w opisie (`meeting:{id}` / `lead:{id}`), a nie przez pole Links — celowo, bo linki przez API to osobne wywołania per rekord. Nie edytuj tych markerów ręcznie.
- **Parser RRULE w W1** obsługuje DAILY, WEEKLY;BYDAY i MONTHLY;BYMONTHDAY. YEARLY/INTERVAL dopiszemy, gdy będą potrzebne.
- **Aktywność w `activities` linkuje leada przez `__LNK_ACT_LEAD__`**; linki do task/meeting są w `payload` (JSON), nie jako Links — mniej wywołań API, timeline i tak czytelny.
- Node'y "Link/Close/Comment" mają `onError: continueRegularOutput` — kosmetyczne niepowodzenie (np. brak uprawnień do komentarzy) nie zatrzyma głównego flow.
